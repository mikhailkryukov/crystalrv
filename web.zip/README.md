# Crystal RV — Website Project
**Live site:** [crystalrv.com](https://crystalrv.com)  
**Business:** Premium Class C RV Rentals — Mountain View, CA (San Francisco Bay Area)  
**Phone:** (669) 245-5636 · **Email:** hello@crystalrv.com

---

## 📁 Project Structure

```
crystalrv/
│
├── index.html                  ← Root page (upload to public_html/)
│
├── css/
│   └── styles.css              ← All site styles (444KB, fully commented)
│
├── js/
│   ├── main.js                 ← Navigation, routing, FAQ, fleet filters, forms
│   ├── articles.js             ← 9 full blog article texts (rendered in modal)
│   └── google-reviews.js       ← Live Google rating auto-sync via Places API
│
└── images/
    ├── logo.png                ← Crystal RV badge logo (navbar + favicon use)
    ├── hero.jpg                ← Hero section background (Big Sur campfire photo)
    ├── daybreak.jpg            ← 2021 Thor Motor Coach Daybreak 22GOC
    ├── conquest.jpg            ← 2022 Gulfstream Conquest 6245
    ├── leprechaun.jpg          ← 2024 Coachmen Leprechaun 220XG
    └── entrada.jpg             ← 2025 East to West Entrada 210NSC
```

---

## 🚀 Deployment — cPanel (Recommended)

1. Log in to your hosting → open **File Manager**
2. Navigate to `public_html/`
3. **Delete** the old `index.html` if present
4. **Upload** `index.html` to `public_html/`
5. **Create folders:** `css/`, `js/`, `images/` inside `public_html/`
6. Upload each file into its matching folder

### Via FTP (FileZilla etc.)
Connect to your host and mirror this folder structure inside `public_html/`. The relative paths (`css/styles.css`, `js/main.js`, `images/hero.jpg`) must be preserved exactly.

---

## ⚙️ Configuration Reference

### Wheelbase Booking Widget
Already configured in `index.html`. No changes needed.
```html
<wheelbase-store dealer-id="1440877" hide-hero="true" show-reviews="true">
```

### Google Analytics
Already installed in `index.html` `<head>`. Tracking ID: `G-T587L369L1`

### Google Reviews Auto-Sync (`js/google-reviews.js`)
API key and Place ID are already set at the top of the file:
```js
const GOOGLE_MAPS_API_KEY = 'AIzaSyCX83S-yoA14DGdt9KmNeC7Fob_JzZX1K0';
const GOOGLE_PLACE_ID     = 'EjAxMDAxIEx...';
```
⚠️ Restrict your API key to `crystalrv.com/*` in Google Cloud Console for security.

---

## 🚐 Fleet

| Year | Make / Model | Sleeps | Length |
|------|-------------|--------|--------|
| 2021 | Thor Motor Coach Daybreak 22GOC | 6 | 24ft |
| 2022 | Gulfstream Conquest 6245 | 5 | 24ft 11in |
| 2024 | Coachmen Leprechaun 220XG | 6 | 24ft 9in |
| 2025 | East to West Entrada 210NSC | 6 | 24ft 4in |

---

## 📄 Pages

| Page | Description |
|------|-------------|
| Home | Hero, fleet preview, why Crystal RV, how it works, testimonials, map, FAQ preview, blog preview, newsletter |
| Fleet | All 4 RVs with full specs, compare feature |
| Booking | Wheelbase widget + trust bar + phone CTA |
| About | Story, team, values, Starlink section, mission |
| Blog | 9 full articles with modal popup reader |
| FAQ | 7 categories, 35+ questions with real policy details |
| Insurance | Full Outdoorsy-identical coverage breakdown |
| Cancellation | Moderate policy — exact terms and payment schedule |
| Contact | Form + map + contact info |

---

## 🔧 Making Changes

### Update RV prices or specs
Search `index.html` for the RV name (e.g. "Thor Daybreak") and edit the card content.

### Add a new blog article
1. Open `js/articles.js`
2. Add a new key to the `articles` object following the existing pattern
3. In `index.html`, add a new `.blog-card` div with `onclick="openArticle('your-key')"`

### Update contact details
Search and replace in `index.html`:
- Phone: `(669) 245-5636`
- Email: `hello@crystalrv.com`
- Address: `1001 La Avenida St, Mountain View, CA 94043`

### Replace RV photos
Drop new `.jpg` files into `images/` using the same filenames:
`daybreak.jpg`, `conquest.jpg`, `leprechaun.jpg`, `entrada.jpg`

---

## 📏 File Sizes

| File | Size |
|------|------|
| index.html | ~116 KB |
| css/styles.css | ~435 KB |
| js/main.js | ~6 KB |
| js/articles.js | ~60 KB |
| js/google-reviews.js | ~4 KB |
| images/hero.jpg | ~295 KB |
| images/logo.png | ~19 KB |
| images/daybreak.jpg | ~50 KB |
| images/conquest.jpg | ~48 KB |
| images/leprechaun.jpg | ~34 KB |
| images/entrada.jpg | ~46 KB |
| **Total** | **~1.1 MB** |

---

*Built April 2026 · Crystal RV · Mountain View, CA*
