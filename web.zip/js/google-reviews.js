/**
 * Crystal RV — Google Reviews Auto-Sync
 * crystalrv.com
 */

const GOOGLE_MAPS_API_KEY = 'AIzaSyCX83S-yoA14DGdt9KmNeC7Fob_JzZX1K0'; // ← Replace this
  const GOOGLE_PLACE_ID     = 'EjAxMDAxIExhIEF2ZW5pZGEgU3QsIE1vdW50YWluIFZpZXcsIENBIDk0MDQzLCBVU0EiMRIvChQKEglhEMutW7ePgBGgUUAwiHm41hDpByoUChIJD9Qr21a3j4ARWTIw3bO2ep4';            // ← Replace this

  function updateAllRatingElements(rating, totalRatings) {
    const ratingStr   = rating.toFixed(1) + '★';
    const countStr    = totalRatings + '+';
    const stars       = '★'.repeat(Math.round(rating)) + '☆'.repeat(5 - Math.round(rating));

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };

    set('g-rating',          ratingStr);
    set('g-rating-about',    ratingStr);
    set('g-count',           countStr);
    set('g-count-about',     countStr);
    set('g-count-label',     'Google Reviews');
    set('g-platform-rating', stars + ' ' + ratingStr + ' (' + totalRatings + ' reviews)');
    set('g-trust-badge',     ratingStr + ' · ' + totalRatings + ' Google Reviews');

    // Update schema structured data dynamically
    const schemas = document.querySelectorAll('script[type="application/ld+json"]');
    schemas.forEach(s => {
      try {
        const d = JSON.parse(s.textContent);
        if (d.aggregateRating) {
          d.aggregateRating.ratingValue  = rating.toFixed(1);
          d.aggregateRating.reviewCount  = String(totalRatings);
          s.textContent = JSON.stringify(d, null, 2);
        }
      } catch(e) {}
    });
  }

  function loadGoogleReviews() {
    if (!GOOGLE_MAPS_API_KEY || GOOGLE_MAPS_API_KEY === 'AIzaSyCX83S-yoA14DGdt9KmNeC7Fob_JzZX1K0') return;

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places&callback=initPlacesService`;
    script.async = true;
    script.defer = true;
    document.head.appendChild(script);
  }

  window.initPlacesService = function() {
    const dummy = document.createElement('div');
    const service = new google.maps.places.PlacesService(dummy);

    service.getDetails({
      placeId: GOOGLE_PLACE_ID,
      fields: ['rating', 'user_ratings_total', 'name']
    }, function(place, status) {
      if (status === google.maps.places.PlacesServiceStatus.OK && place) {
        const rating       = place.rating        || 5.0;
        const totalRatings = place.user_ratings_total || 0;
        updateAllRatingElements(rating, totalRatings);
        // Cache in sessionStorage so we don't re-fetch on every page nav
        sessionStorage.setItem('gRating',  rating);
        sessionStorage.setItem('gCount',   totalRatings);
      }
    });
  };

  // Use cached value instantly if available, then refresh in background
  (function() {
    const cached = sessionStorage.getItem('gRating');
    if (cached) {
      updateAllRatingElements(parseFloat(cached), parseInt(sessionStorage.getItem('gCount') || '0'));
    }
    window.addEventListener('load', loadGoogleReviews);
  })();