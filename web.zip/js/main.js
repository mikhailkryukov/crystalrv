/**
 * Crystal RV — Main Application Script
 * crystalrv.com
 */

// PAGE ROUTING
  let currentPage = 'home';

  function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const target = document.getElementById('page-' + pageId);
    if (target) {
      target.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      currentPage = pageId;
      updateHeader(pageId);
    }
  }

  function updateHeader(pageId) {
    const header = document.getElementById('siteHeader');
    if (pageId === 'home') {
      header.classList.add('hero-mode');
      // Re-check scroll for hero mode
      handleScroll();
    } else {
      header.classList.remove('hero-mode');
      header.classList.add('scrolled');
    }
  }

  // HEADER SCROLL BEHAVIOR
  function handleScroll() {
    const header = document.getElementById('siteHeader');
    if (currentPage === 'home') {
      if (window.scrollY > 60) {
        header.classList.add('scrolled');
        header.classList.remove('hero-mode');
      } else {
        header.classList.remove('scrolled');
        header.classList.add('hero-mode');
      }
    }
  }
  window.addEventListener('scroll', handleScroll);

  // MOBILE MENU
  function toggleMenu() {
    const nav = document.getElementById('mobileNav');
    nav.classList.toggle('open');
  }

  // FAQ TOGGLE
  function toggleFaq(el) {
    const item = el.closest('.faq-item');
    const wasOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item.open').forEach(i => i.classList.remove('open'));
    if (!wasOpen) item.classList.add('open');
  }

  // WISHLIST
  function toggleWishlist(btn) {
    btn.textContent = btn.textContent === '🤍' ? '❤️' : '🤍';
  }

  // FLEET FILTERING
  function filterFleet(btn, type) {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const cards = document.querySelectorAll('#fleetGrid .rv-card');
    let count = 0;
    cards.forEach(card => {
      if (type === 'all' || card.dataset.type === type || (type === 'sleeps-2' && +card.dataset.sleeps <= 2) || (type === 'sleeps-4' && +card.dataset.sleeps >= 3 && +card.dataset.sleeps <= 4) || (type === 'sleeps-6' && +card.dataset.sleeps >= 5) || (type === 'pet' && card.dataset.pet === 'yes')) {
        card.style.display = '';
        count++;
      } else {
        card.style.display = 'none';
      }
    });
    document.getElementById('fleetCount').textContent = `Showing ${count} RV${count !== 1 ? 's' : ''}`;
  }

  function sortFleet(val) {
    const grid = document.getElementById('fleetGrid');
    const cards = [...grid.querySelectorAll('.rv-card')];
    cards.sort((a, b) => {
      if (val === 'price-asc') return +a.dataset.price - +b.dataset.price;
      if (val === 'price-desc') return +b.dataset.price - +a.dataset.price;
      if (val === 'rating') return +b.dataset.rating - +a.dataset.rating;
      if (val === 'sleeps') return +b.dataset.sleeps - +a.dataset.sleeps;
      return 0;
    });
    cards.forEach(c => grid.appendChild(c));
  }

  // COMPARE
  const compareList = [];
  function toggleCompare(checkbox, name) {
    if (checkbox.checked) {
      if (compareList.length >= 3) {
        checkbox.checked = false;
        alert('You can compare up to 3 RVs at a time.');
        return;
      }
      compareList.push(name);
    } else {
      const idx = compareList.indexOf(name);
      if (idx > -1) compareList.splice(idx, 1);
    }
    const bar = document.getElementById('compareBar');
    const countEl = document.getElementById('compareCount');
    if (compareList.length >= 2) {
      bar.classList.add('visible');
      countEl.textContent = `${compareList.length} RVs selected: ${compareList.join(', ')}`;
    } else {
      bar.classList.remove('visible');
    }
  }

  function showCompare() {
    alert(`Comparing:\n\n${compareList.map((n, i) => `${i+1}. ${n}`).join('\n')}\n\nFull compare table coming soon! Contact us for a side-by-side recommendation.`);
  }

  function clearCompare() {
    compareList.length = 0;
    document.querySelectorAll('#fleetGrid input[type=checkbox]').forEach(c => c.checked = false);
    document.getElementById('compareBar').classList.remove('visible');
  }

  // FORM HANDLERS
  function handleBookingSubmit(btn) {
    btn.textContent = '⏳ Sending...';
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = '✅ Reservation Request Sent!';
      btn.style.background = '#2d7050';
    }, 1500);
  }

  function handleContactSubmit(btn) {
    btn.textContent = '⏳ Sending...';
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = '✅ Message Sent — We\'ll reply within 2 hours!';
      btn.style.background = '#2d7050';
    }, 1500);
  }

  function handleNewsletterSignup(btn) {
    const input = btn.previousElementSibling;
    if (!input.value || !input.value.includes('@')) {
      input.style.borderColor = '#e74c3c';
      input.focus();
      return;
    }
    btn.textContent = '✅ You\'re in!';
    btn.disabled = true;
    input.disabled = true;
  }

  // SEARCH - set min dates
  const today = new Date().toISOString().split('T')[0];
  document.querySelectorAll('input[type=date]').forEach(inp => inp.min = today);

  // INIT
  updateHeader('home');